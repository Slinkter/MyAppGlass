# Taller 1 · Hoja de auditoría

**Alumno / pareja:** ______________________

## Cómo llenar cada fila (ejemplo resuelto)

| # | Pasada | Qué viste (evidencia) | Heurística / criterio WCAG | Severidad | Propuesta |
|---|---|---|---|---|---|
| 0 | Visual | El botón "CANCELAR" es rojo, grande y está primero; "Reservar" es pequeño | H4 Consistencia · Ley de Fitts | 3 | Una sola acción primaria ("Confirmar reserva"), grande y al final; "Volver" como enlace |

Una buena evidencia dice **qué** y **dónde**. "El diseño es feo" no es un hallazgo; "el texto de la etiqueta Horarios es #bbb sobre blanco (1.9:1)" sí lo es.

**Severidad (Nielsen):** 0 no es problema · 1 cosmético · 2 menor · 3 mayor · 4 catástrofe (impide reservar)

**Referencias rápidas**
- Heurísticas: H1 Visibilidad del estado · H2 Lenguaje del usuario · H3 Control y libertad · H4 Consistencia ·
  H5 Prevención de errores · H6 Reconocer antes que recordar · H7 Eficiencia · H8 Minimalismo · H9 Recuperarse de errores · H10 Ayuda
- WCAG 2.2 más usados: 1.1.1 Texto alternativo · 1.3.1 Info y relaciones · 1.4.1 Uso del color · 1.4.3 Contraste ·
  1.4.4 Zoom 200 % · 2.1.1 Teclado · 2.2.1 Tiempo ajustable · 2.4.7 Foco visible · 2.5.8 Tamaño del objetivo · 3.1.1 Idioma ·
  3.3.1 Identificación de errores · 3.3.2 Etiquetas · 4.1.2 Nombre, rol, valor

## Tus hallazgos (mínimo 8)

| # | Pasada | Qué viste (evidencia) | Heurística / WCAG | Severidad | Propuesta |
|---|---|---|---|---|---|
| 1 |  |  |  |  |  |
| 2 |  |  |  |  |  |
| 3 |  |  |  |  |  |
| 4 |  |  |  |  |  |
| 5 |  |  |  |  |  |
| 6 |  |  |  |  |  |
| 7 |  |  |  |  |  |
| 8 |  |  |  |  |  |

## Prioriza: tu top 3
Ordena por **severidad alta y esfuerzo bajo** primero.
1.
2.
3.
