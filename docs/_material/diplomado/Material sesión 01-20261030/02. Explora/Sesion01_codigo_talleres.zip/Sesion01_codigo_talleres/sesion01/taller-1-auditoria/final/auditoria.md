# Taller 1 · Auditoría resuelta (18 hallazgos)

| # | Pasada | Evidencia | Heurística / WCAG | Sev. | Corrección | Paso |
|---|---|---|---|---|---|---|
| 1 | Móvil/zoom | `width=1024, user-scalable=no`: en el celular se ve diminuto y no deja hacer zoom | WCAG 1.4.4 · 1.4.10 | 4 | `width=device-width, initial-scale=1` | T1-1 |
| 2 | Contraste | Textos `#999`, `#bbb`, `#ccc` sobre blanco: 2.8:1, 1.9:1 y 1.6:1 | WCAG 1.4.3 | 3 | Texto `#1f2933` (14.8:1) y secundario `#52606d` (6.5:1) | T1-1 |
| 3 | Visual | El placeholder hace de label: al escribir, desaparece el nombre del campo | H6 · WCAG 3.3.2 | 3 | `<label for>` visible encima de cada campo | T1-1 |
| 4 | Lector | `<html>` sin `lang`: el lector pronuncia el español con reglas del inglés | WCAG 3.1.1 | 2 | `<html lang="es">` | T1-1 |
| 5 | Visual | "Booking de Slot", "Submit", códigos `SRV-001` | H2 | 3 | "Reserva tu cita", servicios con nombre, duración y precio | T1-1 |
| 6 | Teclado | `outline:none`: no se ve dónde está el foco | WCAG 2.4.7 | 4 | `:focus-visible` con anillo de 3 px | T1-2 |
| 7 | Teclado | Los horarios son `<span>` con `onclick`: no se alcanzan con Tab | WCAG 2.1.1 · 4.1.2 | 4 | Radio buttons nativos dentro de `fieldset` + `legend` | T1-2 |
| 8 | Visual | Elegir un horario no cambia nada en pantalla | H1 | 4 | Estado seleccionado con color + ✓ | T1-2 |
| 9 | Contraste | Libre (verde) y ocupado (rosado) solo se distinguen por color | WCAG 1.4.1 | 3 | Ocupado tachado, gris y `disabled` | T1-2 |
| 10 | Móvil | Links, horarios y botones de 16–20 px de alto | WCAG 2.5.8 · Fitts | 3 | Mínimo 44 px de alto | T1-2 |
| 11 | Visual | "Error 0x45: VALIDATION_FAILED" | H9 · WCAG 3.3.1 | 3 | Mensaje junto al campo: qué pasó y cómo arreglarlo | T1-3 |
| 12 | Visual | Al fallar la validación se borra todo lo escrito | H5 · H3 | 4 | Conservar datos y llevar el foco al primer error | T1-3 |
| 13 | Lector | El error no se anuncia ni se relaciona con el campo | WCAG 4.1.2 · 3.3.1 | 3 | `aria-invalid`, `aria-describedby`, `aria-live` | T1-3 |
| 14 | Visual | Fecha en texto libre "dd/mm o mm/dd" | H5 | 3 | `input type="date"` | T1-3 |
| 15 | Visual | 6 s de espera sin feedback y luego `alert('OK')` | H1 · Doherty | 3 | Botón "Reservando…" + pantalla de confirmación con código | T1-4 |
| 16 | Visual | 3 botones con estilos distintos; dos hacen lo mismo; el destructivo es el más llamativo | H4 · H8 · Fitts | 3 | Una acción primaria y una secundaria discreta | T1-4 |
| 17 | Visual | "CANCELAR" borra el formulario sin preguntar | H3 | 3 | Confirmar antes de perder datos | T1-4 |
| 18 | Visual | Cuenta regresiva que oculta la oferta y "cobros automáticos" en 10 px gris | WCAG 2.2.1 · H8 · ética | 3 | Eliminar el contador; condiciones legibles | T1-4 |

## Top 3 recomendado
1. **#7 + #8** horarios accesibles y con estado seleccionado: sin ellos no se puede reservar.
2. **#12** no borrar datos ante un error: provoca abandono inmediato.
3. **#1 + #6** zoom y foco visible: una línea de código cada uno.

## Lo que esta auditoría deja para la Sesión 2
Cada hallazgo se puede escribir como una regla para la IA. Ejemplo para `CLAUDE.md`:
"Nunca uses `outline: none`; todo elemento interactivo debe tener un estilo `:focus-visible` con contraste de al menos 3:1."
