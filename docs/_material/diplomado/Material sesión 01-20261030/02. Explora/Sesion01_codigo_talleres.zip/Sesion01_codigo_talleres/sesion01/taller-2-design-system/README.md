# Taller 2 · Design tokens y componentes (25 min)

## Objetivo
Convertir los valores escritos a mano de la pantalla de reserva en un **design system mínimo**:
design tokens en 3 capas + componentes con variantes y estados. Al terminar, la pantalla
no tendrá un solo `#hex` y se podrá cambiar de tema con un atributo.

## Punto de partida
`inicio/` contiene:
- `reserva.html` → el resultado del Taller 1 (accesible, pero con **11 colores distintos repetidos 29 veces**)
- `componentes.html` → la vitrina del design system. **El HTML ya está listo; no lo modifiques.**
- `styles/tokens.css` y `styles/components.css` → esqueletos con `TODO T2-n`

Abre `inicio/componentes.html` con Live Server: se verá sin estilo. A medida que avances, la vitrina cobra vida.

---

## Pasos

### T2-1 · Inventario (3 min)
En `reserva.html` presiona `Ctrl + F` y busca `#`. Anota cada color y **para qué se usa**:

| Color | Dónde aparece | Intención |
|---|---|---|
| `#0b6e75` | botón primario, slot seleccionado, links | acción primaria |
| `#52606d` | subtítulo, hints, condiciones | texto secundario |
| … | … | … |

La columna **Intención** es la que se convierte en token semántico.

### T2-2 · Primitivos (4 min) → `styles/tokens.css`
Crea un token por cada color crudo con el patrón `--familia-escala` (`--teal-600`, `--gray-900`).
Agrega las escalas de espaciado (`--space-1` … `--space-8`), radios y tamaños de letra.

### T2-3 · Semánticos (4 min) → `styles/tokens.css`
Por cada intención del inventario crea un token `--color-rol-variante-estado` que apunte a un primitivo:
`--color-action-primary: var(--teal-600);`

### T2-4 · Tokens de componente (2 min) → `styles/tokens.css`
`--button-height`, `--field-height`, `--card-radius`… apuntan a semánticos o escalas.

### T2-5 · Button: base y variantes (4 min) → `styles/components.css`
Declara tokens locales (`--_bg`, `--_fg`, `--_border`) en `.btn` y úsalos en `background`, `color`, `border`.
Cada variante (`--secondary`, `--danger`, `--link`) **solo reasigna** esos tokens locales.

### T2-6 · Button: estados (4 min) → `styles/components.css`
`:hover`, `:active`, `:focus-visible`, `:disabled` y `.is-loading` (con spinner en `::before`).
Se escriben una sola vez y funcionan para todas las variantes.

### T2-7 · Field, slot, card y badge (4 min) → `styles/components.css`
Copia los estilos de `reserva.html` y cambia cada `#hex` por su token.

### T2-8 · Refactor de `reserva.html` (si te da el tiempo)
Enlaza las dos hojas de estilo, borra los estilos repetidos y usa las clases `btn`, `field__control`, `slot-group`…

### Bonus · Tema oscuro
En `tokens.css` agrega `[data-theme="dark"] { ... }` redefiniendo **solo** los semánticos.
Prueba el botón "Tema oscuro" de la vitrina.

---

## Cómo sabes que terminaste
- [ ] `componentes.html` muestra 4 variantes de botón y 4 estados distintos
- [ ] Con `Tab` ves el anillo de foco en cada botón
- [ ] `Ctrl + F` → `#` en `components.css` devuelve **0 resultados**
- [ ] Cambias `--teal-600` por otro color y **todo** el producto cambia de marca
- [ ] (Bonus) El tema oscuro funciona sin tocar `components.css`

## Lo que sigue
`final/` es el punto de partida del **Taller 3**: con los mismos tokens construimos el catálogo de servicios responsive.
