# Taller 1 · Auditoría UX/UI y corrección accesible (25 min)

## Objetivo
Diagnosticar una pantalla real con las **heurísticas de Nielsen**, las **leyes de UX** y **WCAG 2.2 AA**,
y corregir en código los problemas que impiden reservar.

## Qué necesitas
- VS Code con la extensión **Live Server** (Ritwick Dey)
- Chrome o Edge
- Carpeta `taller-1-auditoria/inicio/`

---

## Parte A · Diagnosticar (10 min)

Abre `inicio/reserva.html` con Live Server. Haz **4 pasadas**, cada una con un objetivo distinto,
y anota cada problema en `inicio/auditoria.md`.

### Pasada 1 · Visual (3 min)
Mírala como cliente. Pregúntate:
- ¿Entiendo qué hace la pantalla y qué botón presionar? (H2, H8)
- Si elijo un horario, ¿veo que quedó elegido? (H1)
- ¿Hay botones que parecen iguales pero hacen cosas distintas, o al revés? (H4)
- Envía el formulario **vacío**: ¿qué pasa con lo que habías escrito? (H5, H9)

### Pasada 2 · Teclado (2 min)
Haz clic en la barra de direcciones y presiona **Tab** repetidamente. **No uses el mouse.**
- ¿Ves en todo momento dónde estás? (WCAG 2.4.7)
- ¿Puedes llegar a los horarios y elegir uno con Espacio? (WCAG 2.1.1)

### Pasada 3 · Móvil y zoom (2 min)
- `F12` → `Ctrl + Shift + M` → elige 360 px de ancho. ¿Se lee? ¿Se puede tocar cada cosa? (WCAG 1.4.10, 2.5.8)
- Vuelve a escritorio y haz `Ctrl` + `+` hasta 200 %. ¿Se pierde algo? (WCAG 1.4.4)

### Pasada 4 · Contraste y herramientas (3 min)
- `F12` → Elements → selecciona el texto "Horarios" → en Styles haz clic en el cuadrado de color:
  DevTools muestra el **contrast ratio**. ¿Llega a 4.5? (WCAG 1.4.3)
- `F12` → pestaña **Lighthouse** → marca solo *Accessibility* → *Analyze page load*. Anota el puntaje.

**Entregable de la Parte A:** mínimo 8 hallazgos y tu top 3.

---

## Parte B · Corregir (12 min)

Aplica estas 4 correcciones sobre `inicio/reserva.html`. Cada una corresponde a una diapositiva de código explicado.
Si te atrasas, compara con `final/reserva.html`: cada cambio está marcado con `[T1-n]`.

| Paso | Qué cambias | Por qué |
|---|---|---|
| **T1-1** | `lang="es"`, viewport sin bloqueo de zoom, `<label>` visibles, colores de texto con contraste ≥ 4.5:1, textos en lenguaje del cliente | WCAG 3.1.1, 1.4.4, 3.3.2, 1.4.3 · H2 |
| **T1-2** | Reemplaza `outline:none` por `:focus-visible`; convierte los `<span>` de horarios en `<input type="radio">` dentro de `<fieldset>`; alto mínimo de 44 px | WCAG 2.4.7, 2.1.1, 4.1.2, 1.4.1, 2.5.8 · H1 |
| **T1-3** | Errores junto a cada campo con `aria-invalid` y `aria-describedby`; **no borres** lo escrito; foco al primer error | WCAG 3.3.1, 3.3.3 · H5, H9 |
| **T1-4** | Botón en estado "Reservando…", pantalla de confirmación, una sola acción primaria, sin cuenta regresiva | H1, H3, H4, H8 · WCAG 2.2.1 |

## Cómo sabes que terminaste
- [ ] Puedes reservar usando **solo el teclado** (Tab, flechas, Espacio, Enter)
- [ ] Al enviar vacío ves 3 mensajes claros y **no se borra nada**
- [ ] Lighthouse Accessibility ≥ 95 (compáralo con el puntaje que anotaste en la Pasada 4)
- [ ] A 360 px no hay scroll horizontal

## Lo que sigue
`final/reserva.html` todavía tiene los colores escritos a mano (`#0b6e75`, `#52606d`…).
Es el punto de partida del **Taller 2**, donde esos valores se convierten en design tokens.
